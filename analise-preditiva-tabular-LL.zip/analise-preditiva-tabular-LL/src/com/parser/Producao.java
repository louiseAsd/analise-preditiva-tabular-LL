package com.parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Producao {
	
	private static String VAZIO = "&";
	
	private char ladoEsquerdo;
	private ArrayList<Regra> regras = new ArrayList<>();
	private String first = "";
	private String follow = "";
	Map<String, String> dadosTabela = new HashMap<String, String>();
	
	public Producao(char ladoEsquerdo, String ladoDireito) {
		this.ladoEsquerdo = ladoEsquerdo;
		setRegras(ladoDireito);
	}
	
	public void addFirst(String terminal) {
		first += terminal;
	}
	
	public void addFollow(String terminal) {
		String formatado = terminal.replaceAll(VAZIO, "");
		follow += formatado;
	}
	
	public void addDadosTabela(String terminal, String acao) {
		dadosTabela.put(terminal, acao);
	}
	
	public void printProducao() {
		System.out.print(ladoEsquerdo + " = ");		
		for(int i=0; i<regras.size(); i++) {
			System.out.print(regras.get(i).getRegra());
			if(i != regras.size()-1) {
				System.out.print(" | ");
			}
		}
		System.out.println();		
	}
	
	public void printDadosTabela() {
		Set<Entry<String, String>> set = dadosTabela.entrySet();
		Iterator<Entry<String, String>> it = set.iterator();
		
		while(it.hasNext()) {
			Entry<String, String> entry = (Entry<String, String>) it.next();
			System.out.println("{" + ladoEsquerdo + "," + entry.getKey() + "}: " + entry.getValue());
		}
	}
	
	public char getLadoEsquerdo() {
		return ladoEsquerdo;
	}

	public ArrayList<Regra> getRegras() {
		return regras;
	}

	public String getFirst() {
		return first;
	}

	public String getFollow() {
		return follow;
	}

	public Map<String, String> getDadosTabela() {
		return dadosTabela;
	}

	private void setRegras(String ladoDireito) {
		
		String regra = "";
		
		for(int i=0; i<ladoDireito.length(); i++) {			
			char atual = ladoDireito.charAt(i);
			if(atual == '|') {
				regras.add(new Regra(regra));
				regra = "";
			} else {
				regra += atual; 
			}			
		}
		regras.add(new Regra(regra));
	}
}
