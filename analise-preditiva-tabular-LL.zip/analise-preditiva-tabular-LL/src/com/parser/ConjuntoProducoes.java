package com.parser;

import java.util.ArrayList;

public class ConjuntoProducoes {
	
	private static String VAZIO = "&";
	private static String FINAL = "$"; 
	
	private ArrayList<Producao> producoes;
	private ArrayList<String> terminais = new ArrayList<>();
	
	public ConjuntoProducoes(ArrayList<Producao> producoes) {
		this.producoes = producoes;
		calculaFirsts();
		calculaFollow();
		montarTabela();
	}
	
	public void printProducoesFistsFollows() {
		for(Producao producao: producoes) {
			producao.printProducao();
		}
		System.out.println();
		
		System.out.println("Firsts:");
		for(Producao producao: producoes) {
			System.out.println(producao.getLadoEsquerdo() + ": {" + producao.getFirst() + "}");
		}
		System.out.println();
		
		System.out.println("Follows:");
		for(Producao producao: producoes) {
			System.out.println(producao.getLadoEsquerdo() + ": {" + producao.getFollow() + "}");
		}
		System.out.println();
		System.out.println("Tabela: ");
		for(Producao producao: producoes) {
			producao.printDadosTabela();
		}
	}
	
	private void calculaFirsts() {
		
		for(int i=producoes.size()-1; i>=0; i--) {
			Producao producao = producoes.get(i);
			for(Regra regra: producao.getRegras()) {
				if(firstRegra2(regra, producao)) {
					continue;
				}
				firstRegra1(regra, producao);
				if(!firstRegra5(regra, producao)) {
					firstRegra3Regra4(regra, producao);
				}
			}
		}		
	}
	
	private void firstRegra1(Regra regra, Producao producao) {
		
		int primeiroNTerminal = -1;
		String sRegra = regra.getRegra();
		
		for(int i=0; i<sRegra.length(); i++) {
			char atual = sRegra.charAt(i);
			if(Character.isUpperCase(atual)) {
				primeiroNTerminal = i;
				break;
			}
		}
		
		if(primeiroNTerminal > 0) {
			char verificar = sRegra.charAt(primeiroNTerminal - 1);
			if(Character.isLowerCase(verificar)) {
				producao.addFirst(String.valueOf(verificar));
				regra.addFirst(String.valueOf(verificar));
			}
		}
		else {
			for(int i=0; i<sRegra.length(); i++) {
				char atual = sRegra.charAt(i);
				if(Character.isLowerCase(atual)) {
					producao.addFirst(String.valueOf(atual));
					regra.addFirst(String.valueOf(atual));
				}
			}
		}
		
	}
	
	private boolean firstRegra2(Regra regra, Producao producao) {
		if(regra.getRegra().equals(VAZIO)) {
			producao.addFirst(VAZIO);
			return true;
		}
		return false;
	}
	
	private void firstRegra3Regra4(Regra regra, Producao producao) {
		
		String sRegra = regra.getRegra();
		
		if(!ehTudoNaoTerminal(sRegra)) {
			return;
		}
		
		String naoContemVazio = "";
		
		for(int i=0; i<sRegra.length()-1; i++) {
			char atual = sRegra.charAt(i);
			String first = encontrarProducao(atual).getFirst();
			if(!first.contains(VAZIO)) {
				naoContemVazio += atual;
			}
		}
		
		if(naoContemVazio.equals("")) {
			String first = encontrarProducao(sRegra.charAt(sRegra.length()-1)).getFirst();
			producao.addFirst(first);
			regra.addFirst(first);
		}
		else {
			for(int i=0; i<naoContemVazio.length(); i++) {
				String first = encontrarProducao(naoContemVazio.charAt(i)).getFirst();
				producao.addFirst(first);
				regra.addFirst(first);
			}
		}
	}

	private boolean firstRegra5(Regra regra, Producao producao) {
		
		String sRegra = regra.getRegra();
		
		if(!ehTudoNaoTerminal(sRegra)) {
			return false;
		}
		
		char primeiro = sRegra.charAt(0);
		String first = encontrarProducao(primeiro).getFirst();
		
		if(!first.contains(VAZIO)) {
			producao.addFirst(first);
			regra.addFirst(first);
			return true;
		}
		return false;
		
	}
	
	private void calculaFollow() {
		followRegra1();
		followRegra2();
		followRegra3();
	}
	
	private void followRegra1() {
		producoes.get(0).addFollow(FINAL);
	}
	
	private void followRegra2() {
		
		for(int i=0; i<producoes.size(); i++) {				
			Producao producao = producoes.get(i);
			
			for(Regra regra: producao.getRegras()) {
				String sRegra = regra.getRegra();
				if(sRegra.length() > 2 && Character.isUpperCase(sRegra.charAt(1))) {
					Producao adicionar = encontrarProducao(sRegra.charAt(1));
					
					for(int j=2; j<sRegra.length(); j++) {
						char atual = sRegra.charAt(j);
						if(Character.isUpperCase(atual)) {
							adicionar.addFollow(encontrarProducao(atual).getFirst());
						}
						if(Character.isLowerCase(atual)) {
							adicionar.addFollow(String.valueOf(atual));
						}
					}	
				}
			}
		}
	}
	
	private void followRegra3() {
		for(int i=0; i<producoes.size(); i++) {
			Producao producao = producoes.get(i);
			
			for(Regra regra: producao.getRegras()) {
				String sRegra = regra.getRegra();
				if(sRegra.length()>1 && Character.isUpperCase(sRegra.charAt(1))){
					
					boolean valido = true;
					Producao adicionar = encontrarProducao(sRegra.charAt(1));
					
					if(sRegra.length() > 2) {
						for(int j=2; j<sRegra.length(); j++) {
							char atual = sRegra.charAt(j);
							if(Character.isUpperCase(atual)) {
								String first = encontrarProducao(atual).getFirst();
								if(!first.contains(VAZIO)) {
									valido = false;
								}
							}
						}
					}
					
					if(valido && adicionar.getLadoEsquerdo() != producao.getLadoEsquerdo()) {
						adicionar.addFollow(producao.getFollow());
					}
					
				}
			}
		}
	}
	
	private boolean ehTudoNaoTerminal(String regra) {
		for(int i=0; i<regra.length(); i++) {
			if(Character.isLowerCase(regra.charAt(i))){
				return false;
			}
		}
		return true;
	}
	
	private Producao encontrarProducao(char ladoEsquerdo) {
		for(Producao producao: producoes) {
			if(producao.getLadoEsquerdo() == ladoEsquerdo) {
				return producao;
			}
		}
		return null;
	}
	
	private void montarTabela() {
		encontrarterminais();
		
		for(Producao producao: producoes) {
			for(Regra regra: producao.getRegras()) {
				String sRegra = regra.getRegra();
				String conjunto;
				
				if(sRegra.contains(VAZIO)) {
					conjunto = producao.getFollow();
				} else {
					conjunto = regra.getFirst();
				}
				
				for(int i=0; i<conjunto.length(); i++) {
					char atual = conjunto.charAt(i);
					String sAtual = String.valueOf(atual);
					if(!sAtual.equals(VAZIO)) {
						producao.addDadosTabela(sAtual, sRegra);
					}
				}
				
			}
		}
	}
	
	private void encontrarterminais() {
		for(Producao producao: producoes) {
			for(Regra regra: producao.getRegras()) {
				String sRegra = regra.getRegra();
				for(int i=0; i<sRegra.length(); i++) {
					char atual = sRegra.charAt(i);
					String sAtual = String.valueOf(atual);
					if(Character.isLowerCase(atual) && !terminais.contains(sAtual)) {
						terminais.add(sAtual);
					}
				}
			}
		}
	}
}
