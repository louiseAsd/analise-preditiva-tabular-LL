package com.parser;

import java.util.ArrayList;

// OBS: CADA TOKEN DEVE SER REPRESENTADO COMO UM CHAR DE A-Z (N�O TERMINAIS), a-z (TERMINAIS) ou & (VAZIO)

public class Principal {

	public static void main(String[] args) {
		
		ArrayList<Producao> producoes = new ArrayList<>();
		
		producoes.add(new Producao('A', "CB"));
		producoes.add(new Producao('B', "aCB|&"));
		producoes.add(new Producao('C', "ED"));
		producoes.add(new Producao('D', "bED|&"));
		producoes.add(new Producao('E', "cE|d"));
		
		/*producoes.add(new Producao('A', "CBE"));
		producoes.add(new Producao('B', "aCBE|&"));
		producoes.add(new Producao('C', "ED"));
		producoes.add(new Producao('D', "bED|&"));
		producoes.add(new Producao('E', "c"));*/
		
		ConjuntoProducoes conjunto = new ConjuntoProducoes(producoes);
		conjunto.printProducoesFistsFollows();
		

	}

}
