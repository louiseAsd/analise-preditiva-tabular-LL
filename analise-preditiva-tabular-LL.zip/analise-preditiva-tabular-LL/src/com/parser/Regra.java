package com.parser;

public class Regra {

	private String regra;
	private String first = "";
	
	public Regra (String regra) {
		this.regra = regra;
	}
	
	public void addFirst(String terminal) {
		first += terminal;
	}

	public String getRegra() {
		return regra;
	}

	public String getFirst() {
		return first;
	}
	
}
